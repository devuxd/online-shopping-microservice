var express = require("express");
var router = express.Router();
var service = require("../service/microservice");
var reviews = require("../service/reviews");
var testEnvironment = true;

router.get("/", function(req, res, next) {
  res.send("List of endpoints: yourRecommendations ");
});

router.get("/yourRecommendations", async (req, res, next) => {
  try {
    const itemList = await service.yourRecommendations(req.query.userId);
    res.json(itemList);
  } catch (e) {
    //this will eventually be handled by your error handling middleware
    if (e instanceof TypeError || e.message == "Illegal Argument Exception") {
      const nullObjects = [
        {
          name: "null",
          description: "null",
          id: "null",
          status: "null",
          groupId: "null",
          price: "null",
          seller: "null",
          rate: "null",
          reviews: {},
        },
      ];
      res.send(nullObjects);
    } else {
      console.log("exception: ", e.message);
      next(e);
    }
  }
});

router.get("/reviewAnItem", async (req, res, next) => {
  try {
    const newReviewId = await reviews.createReviewItem({
      userId: req.query.userId,
      itemId: req.query.itemId,
      comment: req.query.comment,
      rating: req.query.rating,
    });
    res.json({ status: "OK", data: { reviewId: newReviewId } });
  } catch (error) {
    res.json({ status: "Error", error: error.message.toString() });
  }
});

module.exports = router;
