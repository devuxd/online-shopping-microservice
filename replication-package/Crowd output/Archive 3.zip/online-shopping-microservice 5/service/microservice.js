
var firebaseWrapper = require('../third-party-api/firebaseWrapper');
var testEnvironment = true;

// it returns an array of items that user with userId as input arguments viewed before. It gets
//logs of the user and each item has action of viewed wil be returned.
async function yourRecommendations(userId) {
    if (!userId) {
        throw new TypeError('Illegal Argument Exception');
    }
    // var logADT ={
    //     objectType: "logs" , //{logs,reviews,users,items,shoppingCarts}
    //     objectId :  Math.floor(Math.random() * Math.floor(10000000000)),  // random integer less than 1000000000
    //     itemId:2,
    //     action:"viewed",
    //     Date:new Date(),
    //     userId:"eaghayi",
    // }
    // await firebaseWrapper.createObject(logADT);
    const result = [];
    var logsList = await firebaseWrapper.getObjects("logs");
    for (var i = 0; i < logsList.length; i++) {
        if (logsList[i].action === 'viewed' && logsList[i].userId === userId) {
            result.push(logsList[i]);
        }
    }
    console.dir(result);
    return result;
}

// it returns an array of items that matched the "criteria" argument.
async function searchItems(userId, criteria) {
    if (!userId) {
        // don't log the userID
    } else {
        // log userID
    }
    const result = [];
    var logsList = await firebaseWrapper.getObjects("logs");
    for (var i = 0; i < logsList.length; i++) {
        // first, we look at all of the names
        let itemCriteria = logsList[i].itemName;
        if (itemCriteria.includes(criteria)) {
            result.push(logsList[i]);
        }
    }
    if(result.length === 0){
        for (var i = 0; i < logsList.length; i++) {
            // first, we look at all of the names
            let itemCriteria = logsList[i].description;
            if (itemCriteria.includes(criteria)) {
                result.push(logsList[i]);
            }
        }
    }

    console.dir(result);
    return result;
}
// it returns an array of items that matched the "criteria" argument.
async function browseItems(userId, itemName){
    if (!userId) {
        // don't log the userID
    } else {
        // log userID
    }
    const result = [];
    var logsList = await firebaseWrapper.getObjects("logs");
    for (var i = 0; i < logsList.length; i++) {
        // first, we look at all of the names
        let itemCriteria = logsList[i].itemName;
        if (itemCriteria.includes(itemName)) {
            result.push(logsList[i]);
        }
    }
    console.dir(result);
    return result;
}


//Important notes: The endpoint address is "/reviewAnItem". The URL query parameters are: "userId" , "itemId","comment", and "rating".
async function reviewAnItem(userId, itemId, comment, rating) {
    if (!userId) {
        throw new TypeError('You must be logged in to leave a comment.');
    }
    if(comment.length >= 254){
        throw new Error('Review is too long. Max character length = 254')
    }
    if(rating < 1 || rating > 10) {
        throw new Error('Rating needs to be between 1 and 10')
    }
    const result = [];
    var logsList = await firebaseWrapper.getObjects("logs");
    for (var i = 0; i < logsList.length; i++) {
        // first, we look at all of the names
        let itemCriteria = logsList[i].itemName;
        if (itemCriteria === itemId) {
            result.push(logsList[i]);
        }
    }
    if(result.length === 0){
        throw new Error('No item found with name: ' + itemId‌);
    }
    console.dir(result);
    return result;
}

// it returns an array of items in the account of userId
/*
async function fetchShoppingCart(userId) {
    if (!userId) {
        throw new TypeError('Illegal Argument Exception');
    }

    const result = [];
    var logsList = await firebaseWrapper.getObjects("logs");
    for (var i = 0; i < logsList.length; i++) {

        let itemCriteria = logsList[i].itemName;
        if (itemCriteria.includes(criteria)) {
            result.push(logsList[i]);
        }


    }
    console.dir(result);
    return result;
}
*/

module.exports = {
    yourRecommendations: yourRecommendations,
    browseItems: browseItems,
    searchItems: searchItems,
    reviewAnItem: reviewAnItem
    //fetchShoppingCart: fetchShoppingCart

};
