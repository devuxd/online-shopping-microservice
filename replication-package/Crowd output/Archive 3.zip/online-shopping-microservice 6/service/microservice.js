
var firebaseWrapper = require('../third-party-api/firebaseWrapper');
var testEnvironment = true;

// it returns an array of items that user with userId as input arguments viewed before. It gets
//logs of the user and each item has action of viewed wil be returned.
async function yourRecommendations(userId) {
    if (!userId) {
        throw new TypeError('Illegal Argument Exception');
    }
    // var logADT ={
    //     objectType: "logs" , //{logs,reviews,users,items,shoppingCarts}
    //     objectId :  Math.floor(Math.random() * Math.floor(10000000000)),  // random integer less than 1000000000
    //     itemId:2,
    //     action:"viewed",
    //     Date:new Date(),
    //     userId:"eaghayi",
    // }
    // await firebaseWrapper.createObject(logADT);
    const result = [];
    var logsList = await firebaseWrapper.getObjects("logs");
    for (var i = 0; i < logsList.length; i++) {
        if (logsList[i].action === 'viewed' && logsList[i].userId === userId) {
            result.push(logsList[i]);
        }
    }
    console.dir(result);
    return result;

}

//
async function searchItems(criteria, userId, nameOnly) {
    if (criteria === undefined || criteria.trim() === "") {
        throw new TypeError('Illegal Argument Exception');
    }
    criteria = criteria.trim().toLowerCase()

    if (userId !== undefined && userId.trim() !== "") {
        // See coments: https://github.com/devuxd/online-shopping-microservice/issues/1
        firebaseWrapper.createObject("logs", {
            objectType: "logs" , //{logs,reviews,users,items,shoppingCarts}
            objectId: firebaseWrapper.createObjectId(),
            action: nameOnly ? "browsed" : "searched", // {viewed, searched}
            Date: Date.now(),
            userId: userId.trim(),
            criteria: criteria,
        });
    }

    var itemsByName = [];
    var itemsByDescription = [];
    var itemsByCategory = [];
    var items = await firebaseWrapper.getObjects("items");
    for (var i = 0; i < items.length; i++) {
        let itemName = items[i].itemName.toLowerCase();
        if (itemName === criteria) {
            itemsByName.unshift(items[i]);
            continue;
        } else if (itemName.indexOf(criteria) >= 0) {
            itemsByName.push(items[i]);
            continue;
        } else if (nameOnly) {
            continue;
        }

        if (items[i].description.toLowerCase().indexOf(criteria) >= 0) {
            itemsByDescription.push(items[i]);
        } else if (items[i].category.toLowerCase() === criteria) {
            itemsByDescription.push(items[i]);
        }
    }

    var result = itemsByName.concat(itemsByDescription, itemsByCategory);
    console.dir(result);
    return result;
}


module.exports = {
    yourRecommendations: yourRecommendations,
    searchItems: searchItems,
};
