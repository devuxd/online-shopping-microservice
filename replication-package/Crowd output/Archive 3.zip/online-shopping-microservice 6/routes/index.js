var express = require('express');
var router = express.Router();
var service = require('../service/microservice');
var testEnvironment = true;

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });

});

module.exports = router;