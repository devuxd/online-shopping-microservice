var express = require('express'); // (npm install --save express)
var axios = require('axios');
var assert = require('assert');
var firebaseWrapper = require('../third-party-api/firebaseWrapper');


describe('test /service/searchItems', function () {
    it('illegal argument', async function () {
        try {
            const result = await axios.get('http://localhost:3000/service/searchItems', {params: {}});
        }
        catch (e) {
            assert.equal(e.message, 'Request failed with status code 400');
        }

        try {
            const result = await axios.get('http://localhost:3000/service/searchItems', {params: { criteria: '' }});
        }
        catch (e) {
            assert.equal(e.message, 'Request failed with status code 400');
        }

        try {
            const result = await axios.get('http://localhost:3000/service/searchItems', {params: { criteria: '  ' }});
        }
        catch (e) {
            assert.equal(e.message, 'Request failed with status code 400');
        }

        try {
            const result = await axios.get('http://localhost:3000/service/searchItems', {params: { criteria: '  ', userId: 334 }});
        }
        catch (e) {
            assert.equal(e.message, 'Request failed with status code 400');
        }
    });

    it('return items by name', async function () {
        // Exact match
        var result = await axios.get('http://localhost:3000/service/searchItems', {params: { criteria: 'samsungTV'}});
        assert.ok(result.data.length > 0);
        assert.equal(result.data[0].itemName,'samsungTV');

        // Case insensitive
        var result = await axios.get('http://localhost:3000/service/searchItems', {params: { criteria: 'samsungtv'}});
        assert.ok(result.data.length > 0);
        assert.equal(result.data[0].itemName,'samsungTV');

        // Partial match
        result = await axios.get('http://localhost:3000/service/searchItems', {params: { criteria: 'samsung'}});
        assert.ok(result.data.length > 0);
        assert.equal(result.data[0].itemName,'samsungTV');
    });

    it('return items by description', async function () {
        // Match
        var result = await axios.get('http://localhost:3000/service/searchItems', {params: { criteria: 'mart'}});
        assert.ok(result.data.length > 0);
        assert.equal(result.data[0].description,'smart Tv');

        // Case insensitive
        var result = await axios.get('http://localhost:3000/service/searchItems', {params: { criteria: 'Mart'}});
        assert.ok(result.data.length > 0);
        assert.equal(result.data[0].description,'smart Tv');
    });

    it('return items by category', async function () {
        // Exact match
        var result = await axios.get('http://localhost:3000/service/searchItems', {params: { criteria: 'Electric'}});
        assert.ok(result.data.length > 0);
        assert.equal(result.data[0].category,'Electric');

        // Case insensitive
        var result = await axios.get('http://localhost:3000/service/searchItems', {params: { criteria: 'electric'}});
        assert.ok(result.data.length > 0);
        assert.equal(result.data[0].category,'Electric');

        // Partial match
        result = await axios.get('http://localhost:3000/service/searchItems', {params: { criteria: 'ectri'}});
        assert.equal(result.data.length, 0);
    });

    it('return item with specific userId', async function () {
        var userId = firebaseWrapper.createObjectId()

        const oldLogs = await firebaseWrapper.getObjects("logs");

        result = await axios.get('http://localhost:3000/service/searchItems', {params: { criteria: 'samsungTV', userId: userId}});
        assert.ok(result.data.length > 0);

        const newLogs = await firebaseWrapper.getObjects("logs");
        assert.equal(newLogs.length, oldLogs.length + 1);

        var inserted = newLogs[newLogs.length - 1];
        assert.equal(inserted.objectType, "logs")
        assert.equal(inserted.action, "searched")
        assert.equal(inserted.userId, userId)
        assert.equal(inserted.criteria, 'samsungtv')
    })
});
