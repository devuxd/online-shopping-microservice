class NotFoundError extends Error {}

module.exports = { NotFoundError: NotFoundError };
