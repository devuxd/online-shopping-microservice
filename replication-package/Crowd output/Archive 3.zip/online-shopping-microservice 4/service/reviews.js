const NotFoundError = require("../errors/notFoundError.js").NotFoundError;
var firebaseWrapper = require("../third-party-api/firebaseWrapper");
var testEnvironment = true;

// Add a new review to Firebase and returns a fresh list of reviews from the database
async function addReview(userId, itemId, comment, rating) {
  debugger;
  var review = {
    objectType: "reviews",
    objectId: Math.floor(Math.random() * Math.floor(10000000000)),
    itemId: itemId,
    comment: comment,
    userId: userId,
    rating: rating,
  };
  var item = await firebaseWrapper.getObjects("items/" + review.itemId);
  if (item == []) {
    throw new NotFoundError("Item not found");
  }
  await firebaseWrapper.createObject("reviews", review);
  var result = await firebaseWrapper.getObjects("reviews");
  return result;
}

module.exports = {
  addReview: addReview,
};
