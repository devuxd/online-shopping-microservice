async function doPayment(cardNo, CVV2, firstName, LastName, price) {

    return true;

}
async function doShimpment(firstName, lastName, address) {

    return true;
}