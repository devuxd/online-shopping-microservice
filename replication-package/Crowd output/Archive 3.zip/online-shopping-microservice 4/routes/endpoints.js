const NotFoundError = require("../errors/notFoundError.js").NotFoundError;
var express = require("express");
var router = express.Router();
var service = require("../service/microservice");
var reviewsService = require("../service/reviews");
var testEnvironment = true;

router.get("/", function(req, res, next) {
  res.send("List of endpoints: yourRecommendations ");
});

/* POST Review. */
router.post("/reviewanitem", function(req, res, next) {
  try {
    res.json(
      reviewsService.addReview(
        req.body.userId,
        req.body.itemId,
        req.body.comment,
        req.body.rating
      )
    );
  } catch (e) {
    if (e instanceof NotFoundError) {
      next(e);
    }
  }
});

router.get("/yourRecommendations", async (req, res, next) => {
  try {
    const itemList = await service.yourRecommendations(req.query.userId);
    res.json(itemList);
  } catch (e) {
    //this will eventually be handled by your error handling middleware
    if (e instanceof TypeError || e.message == "Illegal Argument Exception") {
      const nullObjects = [
        {
          name: "null",
          description: "null",
          id: "null",
          status: "null",
          groupId: "null",
          price: "null",
          seller: "null",
          rate: "null",
          reviews: {},
        },
      ];
      res.send(nullObjects);
    } else {
      console.log("exception: ", e.message);
      next(e);
    }
  }
});

module.exports = router;
