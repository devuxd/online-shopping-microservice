var firebaseWrapper = require("../third-party-api/firebaseWrapper");
const uuidv4 = require("uuid/v4");
var testEnvironment = true;
const MAX_COMMENT_LENGTH = 254;
const MIN_RATING = 1;
const MAX_RATING = 10;

const ERROR_CODES = {
  100: `userId is required. userId was not found in the request parameters`,
  101: `Invalid userId. userId can not be empty`,
  102: `Invalid userId. userId not found`,
  200: `itemId is required. itemId was not found in the request parameters`,
  201: `Invalid itemId. itemId can not be empty`,
  202: `Invalid itemId. itemId not found`,
  300: `comment was not found. comment was not found in the request parameters`,
  301: `Invalid comment. The comment must be a valid string`,
  302: `Invalid comment. The comment cannot be empty`,
  303: `Max comment length is ${MAX_COMMENT_LENGTH}`,
  400: `rating was not found. rating was not found in the request parameters`,
  401: `Invalid rating. Rating must be a valid number`,
  402: `Rating out of range. Valid range: ${MIN_RATING} - ${MAX_RATING}`,
};

/*
@Description: 
@userId: required, string. The user submitting the review 
@itemId: required, string. The item the review is being submitted for
@rating: required, number. The review rating. range:1-10
@comment: required, string, The review comment. Max length: 254 (see MAX_COMMENT_LENGTH), 
@onerror see attached documentation
*/
async function createReviewItem({ userId, itemId, rating, comment }) {
  // Validations
  if (typeof userId === "undefined") {
    throw new Error(`Code 100: ${ERROR_CODES[100]}`);
  }

  if (userId.length <= 0) {
    throw new Error(`Code 101: ${ERROR[101]}`);
  }

  const user = await firebaseWrapper.getObjects(`users/${userId}`);
  // TODO: remove debug functi
  if (!user.length) {
    throw new Error(`Code 102: ${ERROR_CODES[102]}`);
  }

  if (typeof itemId === "undefined") {
    throw new Error(`Code 200: ${ERROR_CODES[200]}`);
  }

  if (itemId.length <= 0) {
    throw new Error(`Code 201: ${ERROR[201]}`);
  }

  const item = await firebaseWrapper.getObjects(`items/${itemId}`);
  // TODO: remove debug functions
  if (!item.length) {
    throw new Error(`Code 202: ${ERROR_CODES[202]}`);
  }

  if (typeof comment === "undefined") {
    throw new Error(`Code 300: ${ERROR_CODES[300]}`);
  }

  if (typeof comment != "string") {
    throw new Error(`Code 301: ${ERROR_CODES[301]}`);
  }

  if (comment.length <= 0) {
    throw new Error(`Code 302: ${ERROR_CODES[302]}`);
  }

  if (comment.length > MAX_COMMENT_LENGTH) {
    throw new Error(`Code 303: ${ERROR_CODES[303]}`);
  }

  if (typeof rating === "undefined") {
    throw new Error(`Code 400: ${ERROR_CODES[400]}`);
  }

  if (typeof +rating != "number") {
    throw new Error(`Code 401: ${ERROR_CODES[400]}`);
  }

  if (rating < MIN_RATING || rating > MAX_RATING) {
    throw new Error(`Code 402: ${ERROR_CODES[401]}`);
  }

  // Save to database

  const reviewId = uuidv4();
  const reviewKey = await firebaseWrapper.createObject(`reviews`, {
    objectId: reviewId,
    userId: userId,
    itemId: itemId,
    comment: comment,
    rating: rating,
  });

  // Return created reviewId
  return reviewKey;
}

module.exports = {
  createReviewItem,
};
