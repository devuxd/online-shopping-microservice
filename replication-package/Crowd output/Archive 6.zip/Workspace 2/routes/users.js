var express = require("express");
var service = require("../service/microservice");
var router = express.Router();

/* GET users listing. */
router.get("/", async function(req, res, next) {
  const users = await service.getUsers();
  res.send({ status: "OK", data: users });
});

module.exports = router;
