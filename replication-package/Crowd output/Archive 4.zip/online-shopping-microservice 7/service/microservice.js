var firebaseWrapper = require("../third-party-api/firebaseWrapper");
const firebaseApi = require("../third-party-api/firebaseAPI");
var testEnvironment = true;

// it returns an array of items that user with userId as input arguments viewed before. It gets
//logs of the user and each item has action of viewed wil be returned.
async function yourRecommendations(userId) {
  if (!userId) {
    throw new TypeError("Illegal Argument Exception");
  }
  // var logADT ={
  //     objectType: "logs" , //{logs,reviews,users,items,shoppingCarts}
  //     objectId :  Math.floor(Math.random() * Math.floor(10000000000)),  // random integer less than 1000000000
  //     itemId:2,
  //     action:"viewed",
  //     Date:new Date(),
  //     userId:"eaghayi",
  // }
  // await firebaseWrapper.createObject(logADT);
  const result = [];
  var logsList = await firebaseWrapper.getObjects("logs");
  for (var i = 0; i < logsList.length; i++) {
    if (logsList[i].action === "viewed" && logsList[i].userId === userId) {
      result.push(logsList[i]);
    }
  }
  console.dir(result);
  return result;
}

async function addReview(req, res) {
  const { userId, itemId, comment, rating } = req.body;
  if (!userId) {
    return res.status(400).json({ message: "Invalid User" });
  }
  if (!itemId) {
    return res.status(400).json({ message: "Invalid Item Id" });
  }
  if (!comment) {
    return res.status(400).json({ message: "Invalid Comment" });
  }
  if (!rating) {
    return res.status(400).json({ message: "Invalid Rating" });
  }
  const items = await firebaseApi.getItems();
  let itemFound = null;
  await items.forEach(item => {
    if (item.itemId == itemId) {
      itemFound = item;
    }
  });
  if (!!itemFound) {
    await firebaseApi.addOrUpdateReview({
      userId: userId,
      comment: comment,
      rate: rating,
      itemId: itemId,
    });
    return res.status(200).json({ mesage: "Review created Succesfully" });
  } else {
    return res.status(400).json({ message: "Cannot find the item" });
  }
}

async function purchaseHistories(req, res) {
  const { userId } = req.body;
}

module.exports = {
  yourRecommendations: yourRecommendations,
  addReview: addReview,
  purchaseHistories: purchaseHistories,
};
